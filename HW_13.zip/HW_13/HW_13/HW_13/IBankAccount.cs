﻿namespace HW_13

{
    interface IBankAccount
    {
        void CashRefill(NotDepositeAccount accountToRefill, double value);
    }
}
